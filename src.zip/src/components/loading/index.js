import React from 'react';

const Loading = () => <h1>Loading</h1>;

export default Loading;
