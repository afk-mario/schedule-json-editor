import './style.css';

let Footer = () => {
  return '';
};

export default Footer;
