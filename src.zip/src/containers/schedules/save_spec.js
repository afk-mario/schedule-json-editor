const spec = [
  {
    name: 'name',
    label: 'File name',
    type: 'text',
    value: '',
    required: true,
  },
];

export default spec;
